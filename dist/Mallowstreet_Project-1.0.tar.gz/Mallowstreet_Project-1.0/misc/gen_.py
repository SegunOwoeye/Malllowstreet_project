from google import genai

client = genai.Client(api_key="AIzaSyAe3lWLohtskJJ9s5JYMB4y-H4-OjRYKm0")
response = client.models.generate_content(
    model="gemini-2.0-flash", contents="Explain how AI works"
)
print(response.text)